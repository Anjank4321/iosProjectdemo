//
//  SaveViewController.swift
//  Anjan-Project-1
//
//  Created by saikumar pola on 29/08/24.
//

import UIKit

class SaveViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var saveInstance: DetailViewController!
    override func viewDidLoad() {
        super.viewDidLoad()
        saveInstance = DetailViewController()
        // Do any additional setup after loading the view.
    }
   
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return saveInstance.LikedArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell1", for: indexPath) as! CustumTableViewCell
        var movieSearch = UserDefaults.standard.value(forKey: "search") ?? ""
        UserDefaults.standard.synchronize()
        cell.label.text = movieSearch as! String
                return cell
    }
}
