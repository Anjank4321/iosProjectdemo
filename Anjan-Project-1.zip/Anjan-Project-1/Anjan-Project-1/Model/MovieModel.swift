//
//  JSONFile.swift
//  Anjan-Project-1
//
//  Created by saikumar pola on 27/08/24.
//

import Foundation
import UIKit

struct MovieInfo: Decodable {
    var Search: [search]
}
struct search: Codable {
    var Title: String
    var Year: String
    var Poster: String
    var imdbID: String
    var `Type`: String
}
