//
//  UnitTestCaseForView.swift
//  Anjan-Project-1UITests
//
//  Created by saikumar pola on 29/08/24.
//

import XCTest
@testable import Anjan_Project_1

//MARK: - test for JSON
final class UnitTestCaseForView: XCTestCase {
    var apiSetvice = APIService()
    var userInstanace: MockServiceOutput!
    var mockInstance: MockuserServiceOutput!
    var instance: UserViewModels!
    override func setUpWithError() throws {
        try super.setUpWithError()
        
        userInstanace = MockServiceOutput()
        mockInstance = MockuserServiceOutput()
        instance = UserViewModels()
        var viewInstance: APIService!
//        Gommateshwara Lord Bahubali
    }
//    func testsearchView_onAPIAccess() {
//        let apiResult = search(Title: "Gommateshwara Lord Bahubali", Year: "2018", Poster: "https://m.media-amazon.com/images/M/MV5BODVlOWViZTctZjJmNC00YmUyLTg0ODItYzgxNWRmM2NjNGM4XkEyXkFqcGdeQXVyMjY1NzA0Nzc@._V1_SX300.jpg", imdbID: "tt8093880", Type: "movie")
//        instance.fetchMovieDetails = .success(apiResult)
//        XCTAssertTrue(userInstanace.it, true)
//        
//    }
    class MockServiceOutput {
        var fetchMovieDetails: Result<search, Error>?
        func performJson(completion: @escaping(Result<search, Error>)-> Void) {
            if let result = fetchMovieDetails{
                completion(result)
            }
        }
    }
    
    class MockuserServiceOutput {
        var items: [String] = []
        func movieDetails(Istring: String) {
            items.append(Istring)
        }
    }
}
